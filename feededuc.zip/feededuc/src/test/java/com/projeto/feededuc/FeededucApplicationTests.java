package com.projeto.feededuc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeededucApplicationTests {

	@Test
	void contextLoads() {
	}

}
