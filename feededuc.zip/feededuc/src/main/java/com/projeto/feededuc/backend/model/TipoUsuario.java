package com.projeto.feededuc.backend.model;



/**
 * Representa os perfis (roles) de usuário no sistema, 
 * correspondendo às opções do formulário de cadastro.
 */
public enum TipoUsuario {
    ADMINISTRADOR,
    PROFESSOR,
    SETOR_APOIO,
    OPP,
    COORDENADOR,
    LIMPEZA,
    CANTINA,
    MANUTENCAO,
    REFEITORIO,
    AUDITORIO,
    SALAS_DE_AULA,
    ALUNO
}
