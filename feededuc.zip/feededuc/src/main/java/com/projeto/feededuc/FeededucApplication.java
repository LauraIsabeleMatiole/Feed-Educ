	package com.projeto.feededuc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeededucApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeededucApplication.class, args);
	}

}
